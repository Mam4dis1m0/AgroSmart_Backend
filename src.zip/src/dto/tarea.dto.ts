// src/dto/tarea.dto.ts
import {
  IsString,
  IsNumber,
  IsOptional,
  IsInt,
  IsDateString,
  IsBoolean,
  IsIn,
  Min,
} from 'class-validator';

// ── Sin cambios ───────────────────────────────────────────────────────────────
export class CreateTareaDto {
  @IsString() @IsOptional() tipoactividad?: string;
  @IsString() @IsOptional() fechaprogramada?: string;
  @IsNumber() @IsOptional() tiempototaltarea?: number;
  @IsString() @IsOptional() estado?: string;
  @IsString() @IsOptional() esrecurrente?: string;
  @IsNumber() @IsOptional() frecuenciadias?: number;
  @IsNumber() @IsOptional() costototal?: number;
  @IsNumber() @IsOptional() costotransporte?: number;
  @IsNumber() @IsOptional() idadmincreador?: number;
  @IsNumber() @IsOptional() idcultivo?: number;
}

export class UpdateTareaDto extends CreateTareaDto {}

// ── NUEVO ─────────────────────────────────────────────────────────────────────
// Body de PATCH /api/v1/tareas/:id/asignar
// Crea un registro en la tabla asignacion_tarea vinculando
// la tarea con el empleado y el admin que hace la asignación.
export class AsignarTareaDto {
  @IsInt({ message: 'idempleado debe ser un entero.' })
  @Min(1)
  idempleado: number; // empleado que recibirá la tarea

  // Opcional y se IGNORA: el administrador que asigna es el de la sesión (JWT).
  // Se conserva en el DTO para no romper clientes que aún lo envían.
  @IsOptional()
  @IsInt({ message: 'idadminasignador debe ser un entero.' })
  @Min(1)
  idadminasignador?: number;

  @IsOptional()
  @IsDateString()
  fechaasignacion?: string; // si no se envía, se usa la fecha actual

  @IsOptional()
  @IsString()
  estado?: string; // default: 'Asignado'

  @IsOptional()
  @IsNumber()
  pagoacordado?: number;

  // true = reasignación: las asignaciones abiertas de otros empleados pasan a "Reasignada"
  @IsOptional()
  @IsBoolean()
  reemplazar?: boolean;

  // sugerida = el admin aceptó una sugerencia del sistema (queda registrado para análisis posterior)
  @IsOptional()
  @IsIn(['manual', 'sugerida'])
  origenasignacion?: string;
}

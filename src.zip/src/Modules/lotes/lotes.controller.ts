import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
} from '@nestjs/common';
import { LotesService } from './lotes.service';
import { CreateLoteDto, FotoLoteDto, UpdateLoteDto } from '../../dto/lote.dto';
import { Roles } from '../../auth/auth.decorators';

@Controller('lotes')
export class LotesController {
  constructor(private readonly lotesService: LotesService) {}

  @Get() findAll() {
    return this.lotesService.findAll();
  }
  @Post('foto') @Roles('admin') subirFoto(@Body() body: FotoLoteDto) {
    return this.lotesService.subirFoto(body.imagen);
  }
  @Get(':id') findOne(@Param('id') id: string) {
    return this.lotesService.findOne(+id);
  }
  @Post() @Roles('admin') create(@Body() body: CreateLoteDto) {
    return this.lotesService.create(body);
  }
  @Put(':id') @Roles('admin') update(
    @Param('id') id: string,
    @Body() body: UpdateLoteDto,
  ) {
    return this.lotesService.update(+id, body);
  }
  @Delete(':id') @Roles('admin') remove(@Param('id') id: string) {
    return this.lotesService.remove(+id);
  }
}

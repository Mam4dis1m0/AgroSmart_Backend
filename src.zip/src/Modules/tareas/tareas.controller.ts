import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Delete,
  Param,
  Body,
  BadRequestException,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import * as path from 'path';
import { DatosCosecha, TareasService } from './tareas.service';
import {
  CreateTareaDto,
  UpdateTareaDto,
  AsignarTareaDto,
} from '../../dto/tarea.dto';
import { Roles } from '../../auth/auth.decorators';

@Controller('api/v1/tareas')
export class TareasController {
  constructor(private readonly tareasService: TareasService) {}

  @Get()
  findAll() {
    return this.tareasService.findAll();
  }

  @Get('estado/:estado')
  findByEstado(@Param('estado') estado: string) {
    return this.tareasService.findByEstado(estado);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.tareasService.findOne(+id);
  }

  @Post()
  @Roles('admin')
  create(@Body() body: CreateTareaDto) {
    return this.tareasService.create(body);
  }

  // El empleado solo puede cambiar el ESTADO de sus tareas (lo valida el servicio)
  @Put(':id')
  update(@Param('id') id: string, @Body() body: UpdateTareaDto) {
    return this.tareasService.update(+id, body);
  }

  @Delete(':id')
  @Roles('admin')
  remove(@Param('id') id: string) {
    const idNum = parseInt(id, 10);
    if (isNaN(idNum)) throw new BadRequestException('ID inválido');
    return this.tareasService.remove(idNum);
  }

  @Patch(':id/asignar')
  @Roles('admin')
  asignar(@Param('id') id: string, @Body() dto: AsignarTareaDto) {
    return this.tareasService.asignar(+id, dto);
  }

  // :id es el de la ASIGNACIÓN. `at` (opcional) es la hora real del toque si el celular estaba sin red.
  @Patch(':id/iniciar')
  iniciar(@Param('id') id: string, @Body() body: { at?: string }) {
    return this.tareasService.iniciar(+id, body?.at);
  }

  // En una tarea de cosecha, `cosecha` trae lo recolectado: queda registrado en Cosechas.
  @Patch(':id/finalizar')
  finalizar(
    @Param('id') id: string,
    @Body() body: { at?: string; cosecha?: DatosCosecha },
  ) {
    return this.tareasService.completar(+id, body?.at, body?.cosecha);
  }

  @Patch(':id/completar')
  completar(
    @Param('id') id: string,
    @Body() body: { at?: string; cosecha?: DatosCosecha },
  ) {
    return this.tareasService.completar(+id, body?.at, body?.cosecha);
  }

  // ── NUEVO ─────────────────────────────────────────────────────────────────
  @Post(':id/completar-con-evidencia')
  @Roles('empleado')
  @UseInterceptors(
    FileInterceptor('evidencia', {
      storage: diskStorage({
        destination: './uploads/evidencias',
        filename: (req, file, cb) =>
          cb(null, `${Date.now()}-${file.originalname}`),
      }),
    }),
  )
  completarConEvidencia(
    @Param('id') id: string,
    @Body() body: any,
    @UploadedFile() file?: any,
  ) {
    return this.tareasService.completarConEvidencia(
      +id,
      body,
      file?.path ?? null,
    );
  }
}

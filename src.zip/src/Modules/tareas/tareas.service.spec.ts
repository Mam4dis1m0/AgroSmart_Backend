import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { TareasService } from './tareas.service';
// AJUSTA estos imports a las rutas reales de tus entidades
import { Tarea } from './entities/tarea.entity';
import { Empleado } from '../empleado/entities/empleado.entity';
import { AsignacionTarea } from '../asignacion-tarea/entities/asignacion-tarea.entity';
import { Insumo } from '../insumos/entities/insumo.entity';
import { DetalleTarea } from '../detalle-tarea/entities/detalle-tarea.entity';
import { MailService } from '../../mail/mail.service';
import { CacheService } from '../../cache/cache.service';
import { OfflineQueueService } from '../../offline-queue/offline-queue.service';
import { SyncService } from '../../sync/sync.service';
import {
  mockCacheService,
  mockOfflineQueueService,
  mockSyncService,
  mockMailService,
  createMockRepository,
} from '../../../test/mocks/common-providers.mock';

describe('TareasService', () => {
  let service: TareasService;

  const mockTareaRepository = createMockRepository();
  const mockEmpleadoRepository = createMockRepository();
  const mockAsignacionTareaRepository = createMockRepository();
  const mockInsumoRepository = createMockRepository();
  const mockDetalleTareaRepository = createMockRepository();

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TareasService,
        { provide: getRepositoryToken(Tarea), useValue: mockTareaRepository },
        { provide: getRepositoryToken(Empleado), useValue: mockEmpleadoRepository },
        { provide: getRepositoryToken(AsignacionTarea), useValue: mockAsignacionTareaRepository },
        { provide: getRepositoryToken(Insumo), useValue: mockInsumoRepository },
        { provide: getRepositoryToken(DetalleTarea), useValue: mockDetalleTareaRepository },
        { provide: MailService, useValue: mockMailService },
        { provide: CacheService, useValue: mockCacheService },
        { provide: OfflineQueueService, useValue: mockOfflineQueueService },
        { provide: SyncService, useValue: mockSyncService },
      ],
    }).compile();

    service = module.get<TareasService>(TareasService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // TODO: agrega aquí los tests de cada método de TareasService.
});

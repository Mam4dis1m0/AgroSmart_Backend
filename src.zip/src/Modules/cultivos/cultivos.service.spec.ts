import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { CultivosService } from './cultivos.service';
// AJUSTA este import a la ruta real de tu entidad Cultivo
import { Cultivo } from './entities/cultivo.entity';
import { CacheService } from '../../cache/cache.service';
import { OfflineQueueService } from '../../offline-queue/offline-queue.service';
import { SyncService } from '../../sync/sync.service';
import {
  mockCacheService,
  mockOfflineQueueService,
  mockSyncService,
  createMockRepository,
} from '../../../test/mocks/common-providers.mock';

describe('CultivosService', () => {
  let service: CultivosService;
  const mockCultivoRepository = createMockRepository();

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CultivosService,
        { provide: getRepositoryToken(Cultivo), useValue: mockCultivoRepository },
        { provide: CacheService, useValue: mockCacheService },
        { provide: OfflineQueueService, useValue: mockOfflineQueueService },
        { provide: SyncService, useValue: mockSyncService },
      ],
    }).compile();

    service = module.get<CultivosService>(CultivosService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // TODO: agrega aquí los tests de cada método, por ejemplo:
  // it('debería retornar todos los cultivos', async () => {
  //   mockCultivoRepository.find.mockResolvedValue([{ id: 1, nombre: 'Palma' }]);
  //   const result = await service.findAll();
  //   expect(result).toEqual([{ id: 1, nombre: 'Palma' }]);
  // });
});

/**
 * NOTA IMPORTANTE:
 * El log de error mostraba el token de inyección como el string
 * "CultivoRepository" en vez de la clase Repository<Cultivo>.
 * Eso ocurre si tu servicio usa @Inject('CultivoRepository') con un
 * provider personalizado en vez de @InjectRepository(Cultivo) estándar
 * de TypeORM. Revisa el constructor real de CultivosService:
 *
 *   - Si usa @InjectRepository(Cultivo) -> usa getRepositoryToken(Cultivo) (como aquí).
 *   - Si usa @Inject('CultivoRepository') -> reemplaza por:
 *       { provide: 'CultivoRepository', useValue: mockCultivoRepository }
 */

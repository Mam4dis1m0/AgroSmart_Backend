// src/common/sync.service.ts
import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { Cron, CronExpression, Interval } from '@nestjs/schedule';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { OfflineQueueService } from './offline-queue.service';
import { CacheService } from './cache.service';
import { MailService } from '../mail/mail.service';

@Injectable()
export class SyncService implements OnModuleInit {
  private readonly logger = new Logger(SyncService.name);
  private syncing = false;
  private _online = false;
  private _lastCheck = 0;
  private reintentos = new Map<string, number>();
  private readonly CHECK_INTERVAL_MS = 5_000;
  private readonly CHECK_TIMEOUT_MS = 3_000;
  private readonly PROBE_STALE_MS = 10_000;

  // Sonda de conexión en vuelo (evita acumular queries colgadas en el pool)
  private probe: Promise<boolean> | null = null;
  private probeStartedAt = 0;

  constructor(
    @InjectDataSource() private dataSource: DataSource,
    private queue: OfflineQueueService,
    private cache: CacheService,
    private mailService: MailService,
  ) {}

  async onModuleInit() {
    this._online = await this.checkConnection();
    this._lastCheck = Date.now();

    if (this._online) {
      this.logger.log('✅ Conectado a Supabase — modo online');
      await this.precargarEmpleados();
    } else {
      this.logger.warn('📴 Sin conexión a Supabase — modo offline activado');
      this.logger.warn('   Los datos se guardarán en caché local (.cache/)');
    }
  }

  /**
   * Latido: revisa la conexión cada 5 s aunque no haya peticiones ni cola.
   * Es lo que hace que la consola avise "Conexión perdida / restaurada" al instante.
   */
  @Interval(5_000)
  async heartbeat() {
    this._lastCheck = Date.now();
    this.aplicarEstado(await this.checkConnection());
  }

  /**
   * Precarga los empleados de CADA finca en su propia entrada de caché
   * (empleado_f<idfinca>_all) para poder asignar tareas sin conexión.
   * Nunca se mezcla el personal de una finca con el de otra.
   */
  private async precargarEmpleados() {
    try {
      const filas = await this.dataSource.query(`
        SELECT fu.idfinca, e.idusuario, e.montoporhora, e.montoporjornal,
               u.primernombre, u.primerapellido, u.email,
               json_build_object(
                 'primernombre', u.primernombre,
                 'primerapellido', u.primerapellido,
                 'email', u.email
               ) AS idusuario2
        FROM empleado e
        JOIN usuario u        ON e.idusuario = u.idusuario
        JOIN finca_usuario fu ON fu.idusuario = e.idusuario AND fu.rol = 'empleado' AND fu.activo = true
      `);

      const porFinca = new Map<number, any[]>();
      for (const { idfinca, ...empleado } of filas) {
        if (!porFinca.has(idfinca)) porFinca.set(idfinca, []);
        porFinca.get(idfinca)!.push(empleado);
      }
      for (const [idfinca, empleados] of porFinca) {
        this.cache.set(`empleado_f${idfinca}_all`, empleados);
      }
      this.logger.log(
        `✅ Caché de empleados precargada (${filas.length} empleados en ${porFinca.size} finca(s))`,
      );
    } catch (err) {
      this.logger.warn(
        `⚠️ No se pudo precargar caché de empleados: ${err.message}`,
      );
    }
  }

  /**
   * Comprueba la conexión con un SELECT 1.
   * - Timeout corto (3 s) para detectar la caída rápido.
   * - Solo hay una sonda en vuelo a la vez: si la anterior sigue colgada
   *   (socket muerto), no se abre otra conexión del pool; se espera al timeout.
   *   Si lleva más de PROBE_STALE_MS colgada, se lanza una nueva para no
   *   quedar bloqueados cuando el wifi vuelva.
   */
  private async checkConnection(): Promise<boolean> {
    const ahora = Date.now();
    if (!this.probe || ahora - this.probeStartedAt > this.PROBE_STALE_MS) {
      this.probeStartedAt = ahora;
      const sonda: Promise<boolean> = (async () => {
        try {
          if (!this.dataSource.isInitialized) {
            await this.dataSource.initialize();
          }
          await this.dataSource.query('SELECT 1');
          return true;
        } catch {
          return false;
        }
      })().finally(() => {
        if (this.probe === sonda) this.probe = null;
      });
      this.probe = sonda;
    }

    let timer: NodeJS.Timeout;
    const timeout = new Promise<boolean>((resolve) => {
      timer = setTimeout(() => resolve(false), this.CHECK_TIMEOUT_MS);
    });

    try {
      return await Promise.race([this.probe, timeout]);
    } finally {
      clearTimeout(timer!);
    }
  }

  private aplicarEstado(online: boolean) {
    if (online !== this._online) {
      this._online = online;
      this.logger.log(
        online
          ? '✅ Conexión restaurada — modo online'
          : '📴 Conexión perdida — modo offline',
      );
      if (online) this.precargarEmpleados();
    }
  }

  /** Marca el servidor como offline de inmediato (p. ej. cuando una query falla por conexión). */
  marcarOffline() {
    this._lastCheck = Date.now();
    this.aplicarEstado(false);
  }

  async isOnline(): Promise<boolean> {
    const now = Date.now();
    if (now - this._lastCheck < this.CHECK_INTERVAL_MS) {
      return this._online;
    }
    this._lastCheck = now;

    // Si estábamos offline, esperamos el chequeo real: así el primer intento después de
    // recuperar la conexión (o de un arranque lento) ya no cae por error al modo offline.
    if (!this._online) {
      this.aplicarEstado(await this.checkConnection());
      return this._online;
    }

    // Si estábamos online, no bloqueamos la petición: se actualiza en segundo plano.
    // `void` + `.catch`: es una tarea en segundo plano; si el chequeo falla no debe tumbar el proceso.
    void this.checkConnection()
      .then((online) => this.aplicarEstado(online))
      .catch((err) =>
        this.logger.warn(
          `No se pudo verificar la conexión: ${err?.message ?? err}`,
        ),
      );
    return this._online;
  }

  @Cron(CronExpression.EVERY_30_SECONDS)
  async uploadPending() {
    if (this.syncing) return;

    const pending = this.queue.getAll();
    if (pending.length === 0) return;

    const online = await this.isOnline();
    if (!online) {
      this.logger.log(
        `📴 Sin internet — ${pending.length} operaciones en cola esperando`,
      );
      return;
    }

    this.syncing = true;
    try {
      this.logger.log(
        `🔄 Sincronizando ${pending.length} operación(es) pendiente(s)...`,
      );

      const orden = [
        'tarea',
        'asignacion_tarea',
        'detalle_tarea',
        '_email_pendiente',
        '_registro_usuario',
      ];
      const sorted = [
        ...pending.filter((op) => op.entity === 'tarea'),
        ...pending.filter((op) => op.entity === 'asignacion_tarea'),
        ...pending.filter((op) => op.entity === 'detalle_tarea'),
        ...pending.filter((op) => op.entity === '_email_pendiente'),
        ...pending.filter((op) => op.entity === '_registro_usuario'),
        ...pending.filter((op) => !orden.includes(op.entity)),
      ];

      for (const op of sorted) {
        try {
          await this.executeOperation(op);
          this.queue.remove(op.id);
          this.reintentos.delete(op.id);
          this.logger.log(
            `  ✅ ${op.operation} en ${op.entity} — sincronizado`,
          );
        } catch (err) {
          const msg: string = err?.message ?? String(err);

          const irrecuperable =
            msg.startsWith('[DESCARTAR]') ||
            msg.includes('out of range') ||
            msg.includes('invalid input syntax') ||
            (msg.includes('column') && msg.includes('does not exist')) ||
            msg.includes('violates not-null');

          if (irrecuperable) {
            this.queue.remove(op.id);
            this.reintentos.delete(op.id);
            this.logger.error(
              `  ❌ [DESCARTADO] ${op.id} — error irrecuperable: ${msg}`,
            );
          } else {
            const intentos = (this.reintentos.get(op.id) ?? 0) + 1;
            this.reintentos.set(op.id, intentos);

            if (intentos >= 20) {
              this.queue.remove(op.id);
              this.reintentos.delete(op.id);
              this.logger.error(
                `  ❌ [DESCARTADO por límite] ${op.id} — después de 20 intentos: ${msg}`,
              );
            } else {
              this.logger.error(
                `  ❌ ${op.id} falló (intento ${intentos}/20): ${msg}`,
              );
            }
          }
        }
      }

      const restantes = this.queue.count();
      if (restantes === 0) {
        this.logger.log('✅ Cola vacía — todo sincronizado con Supabase');
      } else {
        this.logger.warn(`⚠️  Quedan ${restantes} operaciones sin sincronizar`);
      }
    } finally {
      this.syncing = false;
    }
  }

  private async executeOperation(op: any) {
    const { entity, operation, data } = op;

    // ── Email pendiente ─────────────────────────────────────────────────────
    if (entity === '_email_pendiente') {
      await this.procesarEmailPendiente(data);
      return;
    }

    // ── Registro usuario ────────────────────────────────────────────────────
    if (entity === '_registro_usuario') {
      await this.syncRegistroUsuario(data);
      return;
    }

    // ── DELETE ──────────────────────────────────────────────────────────────
    if (operation === 'DELETE') {
      const pk = Object.keys(data)[0];
      const pkValue = data[pk];
      if (pkValue === undefined || pkValue === null || isNaN(Number(pkValue))) {
        this.logger.error(`  ❌ DELETE descartado — id inválido: ${pkValue}`);
        return;
      }
      // Si la operación trae idfinca (tabla multi-tenant) solo se borra la fila de ESA finca
      if (Object.prototype.hasOwnProperty.call(data, 'idfinca')) {
        const filtroFinca =
          data.idfinca === null ? 'idfinca IS NULL' : 'idfinca = $2';
        const params =
          data.idfinca === null
            ? [Number(pkValue)]
            : [Number(pkValue), Number(data.idfinca)];
        await this.dataSource.query(
          `DELETE FROM "${entity}" WHERE ${pk} = $1 AND ${filtroFinca}`,
          params,
        );
        return;
      }
      await this.dataSource.query(`DELETE FROM "${entity}" WHERE ${pk} = $1`, [
        Number(pkValue),
      ]);
      return;
    }

    // ── CREATE especial: tarea (excluye idtarea negativo) ───────────────────
    if (entity === 'tarea' && operation === 'CREATE') {
      const cleanData = Object.fromEntries(
        Object.entries(data).filter(([k, v]) => {
          if (k.startsWith('_')) return false;
          if (k === 'idtarea') return false; // excluye id temporal negativo
          if (typeof v === 'string' && v.startsWith('offline_')) return false;
          return true;
        }),
      );

      const cols = Object.keys(cleanData).join(', ');
      const vals = Object.values(cleanData);
      const placeholders = vals.map((_, i) => `$${i + 1}`).join(', ');

      const result = await this.dataSource.query(
        `INSERT INTO tarea (${cols}) VALUES (${placeholders}) RETURNING idtarea`,
        vals,
      );

      const idReal = result[0]?.idtarea;
      const idTemporal = data.idtarea;
      this.logger.log(`  ✅ Tarea offline → id real: ${idReal}`);

      // Actualiza asignaciones Y detalles pendientes con el id real
      if (idReal && idTemporal < 0) {
        const queue = this.queue.getAll();
        let cambios = 0;
        for (const pendiente of queue) {
          if (
            (pendiente.entity === 'asignacion_tarea' ||
              pendiente.entity === 'detalle_tarea') &&
            pendiente.data.idtarea === idTemporal
          ) {
            pendiente.data.idtarea = idReal;
            cambios++;
          }
        }
        if (cambios > 0) {
          const fs = require('fs');
          const queueFile = (this.queue as any).queueFile;
          fs.writeFileSync(queueFile, JSON.stringify(queue, null, 2));
          this.logger.log(
            `  🔄 ${cambios} operación(es) actualizadas: ${idTemporal} → ${idReal}`,
          );
        }
      }
      return;
    }

    // ── CREATE especial: asignacion_tarea — verifica FK ────────────────────
    if (entity === 'asignacion_tarea' && operation === 'CREATE') {
      const idtarea = data.idtarea;
      if (idtarea < 0)
        throw new Error(`Tarea padre #${idtarea} aún no sincronizada`);

      const existe = await this.dataSource.query(
        `SELECT idtarea FROM tarea WHERE idtarea = $1`,
        [idtarea],
      );
      if (!existe.length)
        throw new Error(`Tarea #${idtarea} no existe en Supabase todavía`);

      const cleanData = Object.fromEntries(
        Object.entries(data).filter(([k, v]) => {
          if (k.startsWith('_')) return false;
          if (typeof v === 'string' && v.startsWith('offline_')) return false;
          return true;
        }),
      );

      const cols = Object.keys(cleanData).join(', ');
      const vals = Object.values(cleanData);
      const placeholders = vals.map((_, i) => `$${i + 1}`).join(', ');
      await this.dataSource.query(
        `INSERT INTO asignacion_tarea (${cols}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,
        vals,
      );
      return;
    }

    // ── CREATE especial: detalle_tarea — verifica FK ────────────────────────
    if (entity === 'detalle_tarea' && operation === 'CREATE') {
      const idtarea = data.idtarea;
      if (idtarea < 0)
        throw new Error(`Tarea padre #${idtarea} aún no sincronizada`);

      const existe = await this.dataSource.query(
        `SELECT idtarea FROM tarea WHERE idtarea = $1`,
        [idtarea],
      );
      if (!existe.length)
        throw new Error(`Tarea #${idtarea} no existe en Supabase todavía`);

      const cleanData = Object.fromEntries(
        Object.entries(data).filter(([k, v]) => {
          if (k.startsWith('_')) return false;
          if (typeof v === 'string' && v.startsWith('offline_')) return false;
          return true;
        }),
      );

      const cols = Object.keys(cleanData).join(', ');
      const vals = Object.values(cleanData);
      const placeholders = vals.map((_, i) => `$${i + 1}`).join(', ');
      await this.dataSource.query(
        `INSERT INTO detalle_tarea (${cols}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,
        vals,
      );
      return;
    }

    // ── CREATE / UPDATE genérico ────────────────────────────────────────────
    const cleanData = Object.fromEntries(
      Object.entries(data).filter(([k, v]) => {
        if (k.startsWith('_')) return false;
        if (typeof v === 'string' && v.startsWith('offline_')) return false;
        return true;
      }),
    );

    const cols = Object.keys(cleanData).join(', ');
    const vals = Object.values(cleanData);
    const placeholders = vals.map((_, i) => `$${i + 1}`).join(', ');

    if (operation === 'CREATE') {
      await this.dataSource.query(
        `INSERT INTO "${entity}" (${cols}) VALUES (${placeholders})`,
        vals,
      );
      return;
    }

    const pk = Object.keys(cleanData)[0];

    // Tablas multi-tenant: UPDATE acotado a la finca. Nunca un upsert, que podría pisar
    // una fila de OTRA finca si el id coincide (RNF-16).
    if (Object.prototype.hasOwnProperty.call(cleanData, 'idfinca')) {
      const {
        [pk]: pkValue,
        idfinca,
        ...campos
      } = cleanData as Record<string, unknown>;
      const nombres = Object.keys(campos);
      if (nombres.length === 0) return;

      const sets = nombres.map((k, i) => `"${k}" = $${i + 1}`).join(', ');
      const params: unknown[] = [...Object.values(campos), pkValue];
      let filtroFinca = 'idfinca IS NULL';
      if (idfinca !== null && idfinca !== undefined) {
        params.push(idfinca);
        filtroFinca = `idfinca = $${params.length}`;
      }
      const resultado = await this.dataSource.query(
        `UPDATE "${entity}" SET ${sets} WHERE ${pk} = $${nombres.length + 1} AND ${filtroFinca} RETURNING ${pk}`,
        params,
      );
      if (filasActualizadas(resultado) === 0) {
        this.logger.warn(
          `  ⚠️ UPDATE descartado: ${entity} #${String(pkValue)} no existe en la finca ${String(idfinca)}`,
        );
      }
      return;
    }

    const updates = Object.keys(cleanData)
      .map((k, i) => `${k} = $${i + 1}`)
      .join(', ');

    await this.dataSource.query(
      `INSERT INTO "${entity}" (${cols})
       VALUES (${placeholders})
       ON CONFLICT (${pk}) DO UPDATE SET ${updates}`,
      vals,
    );
  }

  private async procesarEmailPendiente(data: any) {
    if (!data?.tipo || !data?.emailDestino) return;
    if (data.tipo === 'tareaAsignada') {
      await this.mailService.notificarTareaAsignada(
        data.emailDestino,
        data.nombreTarea ?? 'Sin nombre',
      );
      this.logger.log(
        `  📧 Email tareaAsignada enviado a ${data.emailDestino}`,
      );
    }
  }

  private async syncRegistroUsuario(data: any) {
    const {
      userData,
      role,
      montoporhora,
      montoporjornal,
      montomensual,
      tipopago,
      valorpago,
      idfinca,
      ubicacion,
      latitud,
      longitud,
    } = data;

    const cleanUser = Object.fromEntries(
      Object.entries(userData as Record<string, unknown>).filter(([k, v]) => {
        if (k.startsWith('_')) return false;
        if (typeof v === 'string' && v.startsWith('offline_')) return false;
        return true;
      }),
    );

    const cols = Object.keys(cleanUser).join(', ');
    const vals = Object.values(cleanUser);
    const placeholders = vals.map((_, i) => `$${i + 1}`).join(', ');

    // Si el correo ya existe NO se sobrescribe la cuenta de otra persona: se descarta la operación.
    const result = await this.dataSource.query(
      `INSERT INTO usuario (${cols})
       VALUES (${placeholders})
       ON CONFLICT (email) DO NOTHING
       RETURNING idusuario`,
      vals,
    );
    const idusuario = result[0]?.idusuario;
    if (!idusuario) {
      throw new Error(
        '[DESCARTAR] El correo ya está registrado: se descarta el registro offline',
      );
    }

    if (role === 'admin') {
      await this.dataSource.query(
        `INSERT INTO administrador (idusuario, montomensual)
         VALUES ($1, $2)
         ON CONFLICT (idusuario) DO UPDATE SET montomensual = $2`,
        [idusuario, montomensual ?? 0],
      );
    } else if (role === 'comprador') {
      await this.dataSource.query(
        `INSERT INTO comprador_perfil (idusuario, ubicacion, latitud, longitud)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (idusuario) DO NOTHING`,
        [idusuario, ubicacion ?? null, latitud ?? null, longitud ?? null],
      );
    } else {
      await this.dataSource.query(
        `INSERT INTO empleado (idusuario, montoporhora, montoporjornal, tipopago, valorpago)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (idusuario) DO UPDATE SET montoporhora = $2, montoporjornal = $3, tipopago = $4, valorpago = $5`,
        [
          idusuario,
          montoporhora ?? 0,
          montoporjornal ?? 0,
          tipopago ?? 'dia',
          valorpago ?? 0,
        ],
      );
      // El empleado nace dentro de la finca del administrador que lo registró
      if (idfinca) {
        await this.dataSource.query(
          `INSERT INTO finca_usuario (idfinca, idusuario, rol) VALUES ($1, $2, 'empleado')
           ON CONFLICT (idfinca, idusuario) DO NOTHING`,
          [idfinca, idusuario],
        );
      }
    }

    this.logger.log(
      `  👤 Usuario sincronizado: idusuario=${idusuario} rol=${role}`,
    );
  }
}

/** UPDATE ... RETURNING devuelve [filas, n] según la versión de TypeORM; normaliza a cantidad. */
function filasActualizadas(resultado: any): number {
  if (!Array.isArray(resultado)) return 0;
  if (
    resultado.length === 2 &&
    Array.isArray(resultado[0]) &&
    typeof resultado[1] === 'number'
  ) {
    return resultado[1];
  }
  return resultado.length;
}

/**
 * Mocks compartidos para los servicios transversales que casi todos los
 * *.service.spec.ts necesitan mockear (CacheService, OfflineQueueService,
 * SyncService, MailService).
 *
 * Uso:
 *   import {
 *     mockCacheService,
 *     mockOfflineQueueService,
 *     mockSyncService,
 *     mockMailService,
 *   } from '../../../test/mocks/common-providers.mock';
 *
 * Ajusta la ruta relativa según la ubicación real de cada spec.
 */

export const mockCacheService = {
  get: jest.fn(),
  set: jest.fn(),
  del: jest.fn(),
  reset: jest.fn(),
};

export const mockOfflineQueueService = {
  enqueue: jest.fn(),
  dequeue: jest.fn(),
  process: jest.fn(),
};

export const mockSyncService = {
  sync: jest.fn(),
  isOnline: jest.fn().mockReturnValue(true),
};

export const mockMailService = {
  sendMail: jest.fn(),
  sendWelcomeEmail: jest.fn(),
};

// Factory genérica para simular un Repository de TypeORM.
// Cada test puede sobreescribir los métodos que necesite con mockResolvedValue/mockReturnValue.
export const createMockRepository = () => ({
  find: jest.fn(),
  findOne: jest.fn(),
  findOneBy: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
  remove: jest.fn(),
  count: jest.fn(),
  createQueryBuilder: jest.fn(() => ({
    where: jest.fn().mockReturnThis(),
    andWhere: jest.fn().mockReturnThis(),
    orderBy: jest.fn().mockReturnThis(),
    getMany: jest.fn(),
    getOne: jest.fn(),
  })),
});
